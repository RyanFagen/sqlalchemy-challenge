# Import the dependencies.
import numpy as np
import sqlalchemy
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import Session
from sqlalchemy import create_engine, func
from flask import Flask, jsonify
#################################################
# Database Setup
#################################################
engine = create_engine("sqlite:///hawaii.sqlite")

# reflect an existing database into a new model
Base = automap_base()

# reflect the tables
Base.prepare(autoload_with=engine)

# Save references to each table
Measurements = Base.classes.hawaii_measurements
Stations = Base.classes.hawaii_stations

# Create our session (link) from Python to the DB
session = Session(engine)

#################################################
# Flask Setup
#################################################
app = Flask(__name__)

#################################################
# Flask Routes
#################################################

@app.route("/")
def welcome():
    """List all available api routes."""
    return (
        f"Available Routes:<br/>"
        f"/api/v1.0/precipitation<br/>"
        f"/api/v1.0/stations<br/>"
        f"/api/v1.0/tobs<br/>"
        f"/api/v1.0/<start><br/>"
        f"/api/v1.0/<start>/<end>"
    )

@app.route("/api/v1.0/precipitation")
def precipitation():
    # Exploratory Precipitation Analysis
    last_date = session.query(func.max(Measurement.date)).first()
    last_year_date = dt.date(2017, 8, 23) - dt.timedelta(days=365)
    results = session.query(Measurement.date, Measurement.prcp).\
          filter(Measurement.date >= last_year_date).all()
    session.close()

    # Dictionary
    result_dict = []
    for date, prcp in results:
        precipitation_dict = {}
        precipitation_dict["date"] = date
        precipitation_dict["prcp"] = prcp
        result_dict.append(precipitation_dict)
    return jsonify(result_dict)

@app.route("/api/v1.0/stations")
def stations():
    # Query all stations
    results = session.query(Station.station).all()
    session.close()

    # Convert list of tuples into normal list
    all_stations = list(np.ravel(results))
    return jsonify(all_stations)

@app.route("/api/v1.0/tobs")
def tobs():
    # Exploratory Station Analysis
    temp_results = session.query(Measurement.tobs).\
               filter(Measurement.station == 'USC00519281').\
               filter(Measurement.date >= last_year_date).all()
    session.close()

    # Convert list of tuples into normal list
    temp_summary = list(np.ravel(temp_results))
    return jsonify(temp_summary)

@app.route("/api/v1.0/<start>")
def start():
    sel = session.query(func.min(Measurement.tobs), func.avg(Measurement.tobs),   func.max(Measurement.tobs)).all()
    start = dt.datetime.strptime(start, "%m/%d/%Y")
    sel_results = session.query(sel).\
              filter(Measurement.date >= start).all()
    sel_summary = list(np.ravel(sel_results))
    return jsonify(sel_summary)

@app.route("/api/v1.0/<start>/<end>")
def start():
    sel = session.query(func.min(Measurement.tobs), func.avg(Measurement.tobs),   func.max(Measurement.tobs)).all()
    start = dt.datetime.strptime(start, "%m/%d/%Y")
    end = dt.datetime.strptime(end, "%m/%d/%Y")
    sel_results = session.query(sel).\
              filter(Measurement.date >= start).\
              filter(Measurement.date <= end).all()
    sel_summary = list(np.ravel(sel_results))
    return jsonify(sel_summary)